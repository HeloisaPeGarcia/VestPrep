// Simulado Manager - Handles quiz functionality
export const simuladoManager = {
    getSimulado(id) {
        // Fetch the simulado data based on ID
        const allSimulados = window.vueApp.$data.simulados;
        const simuladoBase = allSimulados.find(s => s.id === id);
        
        // Generate questions based on the simulado type and subjects
        return {
            ...simuladoBase,
            questions: this.generateQuestions(simuladoBase)
        };
    },
    
    generateQuestions(simulado) {
        // This would normally fetch from a database
        // For demo purposes, we'll generate some sample questions
        const questions = [];
        const types = {
            'ENEM': ['Múltipla escolha com 5 alternativas', 'Interpretativa'],
            'FUVEST': ['Múltipla escolha com 4 alternativas', 'Analítica'],
            'UNICAMP': ['Múltipla escolha com 4 alternativas', 'Interpretativa']
        };
        
        const subjects = {
            'matematica': ['Geometria', 'Álgebra', 'Funções', 'Estatística'],
            'portugues': ['Interpretação de texto', 'Gramática', 'Literatura'],
            'fisica': ['Mecânica', 'Termodinâmica', 'Eletromagnetismo'],
            'quimica': ['Química Orgânica', 'Química Inorgânica', 'Físico-Química'],
            'biologia': ['Citologia', 'Genética', 'Ecologia'],
            'historia': ['Brasil Colônia', 'Brasil Império', 'Era Vargas'],
            'geografia': ['Geografia Física', 'Geografia Humana', 'Geopolítica'],
            'ingles': ['Interpretação de texto', 'Vocabulário', 'Gramática']
        };
        
        const questionTypes = types[simulado.type];
        const questionCount = Math.min(simulado.questions, 30); // Limit to 30 for demo
        
        for (let i = 0; i < questionCount; i++) {
            let subject, topic;
            
            if (simulado.subjects.includes('todos')) {
                const allSubjects = Object.keys(subjects);
                subject = allSubjects[Math.floor(Math.random() * allSubjects.length)];
            } else {
                subject = simulado.subjects[Math.floor(Math.random() * simulado.subjects.length)];
            }
            
            topic = subjects[subject][Math.floor(Math.random() * subjects[subject].length)];
            
            questions.push({
                id: i + 1,
                text: `Questão ${i + 1}: Esta é uma questão de ${topic} (${subject}) no estilo ${questionTypes[i % questionTypes.length]}.`,
                subject: subject,
                topic: topic,
                options: [
                    `Alternativa A - Uma possível resposta para a questão ${i + 1}`,
                    `Alternativa B - Uma possível resposta para a questão ${i + 1}`,
                    `Alternativa C - Uma possível resposta para a questão ${i + 1}`,
                    `Alternativa D - Uma possível resposta para a questão ${i + 1}`,
                    simulado.type === 'ENEM' ? `Alternativa E - Uma possível resposta para a questão ${i + 1}` : null
                ].filter(Boolean),
                correctAnswer: Math.floor(Math.random() * (simulado.type === 'ENEM' ? 5 : 4))
            });
        }
        
        return questions;
    },
    
    calculateResult(simulado, userAnswers) {
        let correctCount = 0;
        
        for (let i = 0; i < simulado.questions.length; i++) {
            if (userAnswers[i] === simulado.questions[i].correctAnswer) {
                correctCount++;
            }
        }
        
        const percentage = (correctCount / simulado.questions.length) * 100;
        
        return {
            totalQuestions: simulado.questions.length,
            correctAnswers: correctCount,
            percentage: percentage.toFixed(1),
            grade: this.calculateGrade(percentage),
            performance: this.evaluatePerformance(percentage)
        };
    },
    
    calculateGrade(percentage) {
        if (percentage >= 90) return 'A+';
        if (percentage >= 80) return 'A';
        if (percentage >= 70) return 'B';
        if (percentage >= 60) return 'C';
        if (percentage >= 50) return 'D';
        return 'E';
    },
    
    evaluatePerformance(percentage) {
        if (percentage >= 90) return 'Excelente! Você está muito bem preparado!';
        if (percentage >= 70) return 'Muito bom! Continue estudando.';
        if (percentage >= 50) return 'Bom. Você está no caminho certo.';
        if (percentage >= 30) return 'Você precisa estudar mais.';
        return 'Você precisa melhorar bastante. Não desista!';
    }
};