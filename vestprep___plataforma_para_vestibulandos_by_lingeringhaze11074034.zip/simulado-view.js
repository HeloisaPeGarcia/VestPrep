// Component for displaying the simulado taking interface
document.addEventListener('DOMContentLoaded', () => {
    // This code will initialize simulado view components when the page loads
    // It will be used by the app.js when a simulado is started
    console.log('Simulado View module loaded');
});

export function renderQuestion(question, userAnswer, onAnswer) {
    const questionElement = document.createElement('div');
    questionElement.className = 'question-container';
    
    // Question text
    const questionText = document.createElement('div');
    questionText.className = 'question-text';
    questionText.innerHTML = question.text;
    questionElement.appendChild(questionText);
    
    // Options
    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'options-container';
    
    question.options.forEach((option, index) => {
        const optionElement = document.createElement('div');
        optionElement.className = 'option';
        if (userAnswer === index) {
            optionElement.classList.add('selected');
        }
        
        optionElement.onclick = () => onAnswer(index);
        
        const optionLabel = document.createElement('span');
        optionLabel.className = 'option-label';
        optionLabel.textContent = String.fromCharCode(65 + index); // A, B, C, D, E
        
        const optionText = document.createElement('span');
        optionText.className = 'option-text';
        optionText.textContent = option;
        
        optionElement.appendChild(optionLabel);
        optionElement.appendChild(optionText);
        optionsContainer.appendChild(optionElement);
    });
    
    questionElement.appendChild(optionsContainer);
    return questionElement;
}

export function renderResult(result) {
    const resultElement = document.createElement('div');
    resultElement.className = 'result-container';
    
    const resultHeader = document.createElement('h2');
    resultHeader.textContent = 'Resultado do Simulado';
    resultElement.appendChild(resultHeader);
    
    const resultSummary = document.createElement('div');
    resultSummary.className = 'result-summary';
    
    const gradeElement = document.createElement('div');
    gradeElement.className = 'result-grade';
    gradeElement.textContent = result.grade;
    resultSummary.appendChild(gradeElement);
    
    const statsElement = document.createElement('div');
    statsElement.className = 'result-stats';
    statsElement.innerHTML = `
        <p>Acertos: <strong>${result.correctAnswers}/${result.totalQuestions}</strong></p>
        <p>Percentual: <strong>${result.percentage}%</strong></p>
        <p>${result.performance}</p>
    `;
    resultSummary.appendChild(statsElement);
    
    resultElement.appendChild(resultSummary);
    return resultElement;
}