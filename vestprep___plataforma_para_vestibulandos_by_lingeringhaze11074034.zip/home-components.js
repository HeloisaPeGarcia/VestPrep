// Components for enhancing the home page experience
export function renderUpcomingEvents(events) {
    const container = document.createElement('div');
    container.className = 'upcoming-events';
    
    const heading = document.createElement('h3');
    heading.textContent = 'Próximos Eventos';
    container.appendChild(heading);
    
    events.forEach(event => {
        const eventItem = document.createElement('div');
        eventItem.className = 'upcoming-event';
        
        const eventTitle = document.createElement('div');
        eventTitle.className = 'event-title';
        eventTitle.textContent = event.title;
        
        const eventDate = document.createElement('div');
        eventDate.className = 'event-date';
        eventDate.textContent = formatDate(event.date);
        
        const eventCountdown = document.createElement('div');
        eventCountdown.className = 'event-countdown';
        eventCountdown.textContent = formatCountdown(event.daysRemaining);
        
        eventItem.appendChild(eventTitle);
        eventItem.appendChild(eventDate);
        eventItem.appendChild(eventCountdown);
        container.appendChild(eventItem);
    });
    
    return container;
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    return `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
}

function formatCountdown(daysRemaining) {
    if (daysRemaining === 0) return "Hoje!";
    if (daysRemaining === 1) return "Amanhã!";
    return `Faltam ${daysRemaining} dias`;
}

export function createProgressTracker() {
    // This would connect to user data in a real app
    const container = document.createElement('div');
    container.className = 'progress-tracker';
    
    const heading = document.createElement('h3');
    heading.textContent = 'Seu Progresso';
    container.appendChild(heading);
    
    const subjects = [
        { name: 'Matemática', progress: 65 },
        { name: 'Português', progress: 80 },
        { name: 'Física', progress: 45 },
        { name: 'Química', progress: 55 }
    ];
    
    subjects.forEach(subject => {
        const subjectItem = document.createElement('div');
        subjectItem.className = 'subject-progress';
        
        const subjectName = document.createElement('div');
        subjectName.className = 'subject-name';
        subjectName.textContent = subject.name;
        
        const progressBar = document.createElement('div');
        progressBar.className = 'progress-bar';
        
        const progressFill = document.createElement('div');
        progressFill.className = 'progress-fill';
        progressFill.style.width = `${subject.progress}%`;
        
        const progressText = document.createElement('div');
        progressText.className = 'progress-text';
        progressText.textContent = `${subject.progress}%`;
        
        progressBar.appendChild(progressFill);
        progressBar.appendChild(progressText);
        
        subjectItem.appendChild(subjectName);
        subjectItem.appendChild(progressBar);
        container.appendChild(subjectItem);
    });
    
    return container;
}