// Resumo Viewer - Handles content display for study materials
export const resumoViewer = {
    getTopic(topicId) {
        // In a real app, this would fetch from a database
        // For demo, we'll generate content based on topics from config
        const allSubjects = window.app._instance.data.subjects;
        let foundTopic = null;
        
        // Find the topic across all subjects
        for (const subject of allSubjects) {
            const topic = subject.contentTopics.find(t => t.id === topicId);
            if (topic) {
                foundTopic = {
                    ...topic,
                    subjectName: subject.name,
                    subjectColor: subject.color,
                    content: this.generateTopicContent(topic, subject)
                };
                break;
            }
        }
        
        return foundTopic;
    },
    
    generateTopicContent(topic, subject) {
        // This would normally come from a database
        const sections = [];
        
        // Generate random sections based on topic and subject
        switch (subject.name) {
            case 'Matemática':
                if (topic.title === 'Funções') {
                    sections.push({
                        title: 'Definição de Função',
                        content: 'Uma função é uma relação que associa cada elemento de um conjunto (domínio) a exatamente um elemento de outro conjunto (contradomínio).'
                    });
                    sections.push({
                        title: 'Função do 1º Grau',
                        content: 'Uma função do 1º grau, ou função afim, é definida por f(x) = ax + b, onde a e b são números reais e a ≠ 0.'
                    });
                    sections.push({
                        title: 'Função do 2º Grau',
                        content: 'Uma função do 2º grau, ou função quadrática, é definida por f(x) = ax² + bx + c, onde a, b e c são números reais e a ≠ 0.'
                    });
                } else if (topic.title === 'Geometria Plana') {
                    sections.push({
                        title: 'Triângulos',
                        content: 'Um triângulo é um polígono de três lados. A soma dos ângulos internos de um triângulo é sempre 180°.'
                    });
                    sections.push({
                        title: 'Áreas',
                        content: 'Área do triângulo: A = (b × h)/2, onde b é a base e h é a altura.'
                    });
                }
                break;
                
            case 'Física':
                if (topic.title === 'Mecânica') {
                    sections.push({
                        title: 'Leis de Newton',
                        content: '1ª Lei de Newton (Inércia): Um corpo permanece em repouso ou em movimento retilíneo uniforme, a menos que uma força resultante não nula atue sobre ele.'
                    });
                    sections.push({
                        title: 'Cinemática',
                        content: 'Estudo do movimento sem considerar suas causas. Equações do MRU: s = s0 + v.t'
                    });
                }
                break;
                
            default:
                sections.push({
                    title: 'Introdução a ' + topic.title,
                    content: 'Conteúdo introdutório sobre ' + topic.title + ' na disciplina de ' + subject.name + '.'
                });
                sections.push({
                    title: 'Conceitos Principais',
                    content: 'Aqui seriam listados os principais conceitos de ' + topic.title + '.'
                });
        }
        
        // Add examples and exercises sections
        sections.push({
            title: 'Exemplos',
            content: 'Exemplos práticos de aplicação dos conceitos de ' + topic.title + '.'
        });
        
        sections.push({
            title: 'Exercícios Resolvidos',
            content: 'Aqui você encontraria exemplos de exercícios resolvidos passo a passo.'
        });
        
        return sections;
    }
};