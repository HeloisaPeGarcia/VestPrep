// Countdown Timer - Tracks upcoming vestibular events
export const countdownTimer = {
    getUpcomingEvents(events) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Filter events that haven't happened yet and sort by date
        return events
            .filter(event => {
                const eventDate = new Date(event.date);
                return eventDate >= today;
            })
            .sort((a, b) => new Date(a.date) - new Date(b.date))
            .slice(0, 3) // Get only next 3 events
            .map(event => {
                const eventDate = new Date(event.date);
                const daysRemaining = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24));
                
                return {
                    ...event,
                    daysRemaining
                };
            });
    },
    
    formatCountdown(daysRemaining) {
        if (daysRemaining === 0) return "Hoje!";
        if (daysRemaining === 1) return "Amanhã!";
        return `Faltam ${daysRemaining} dias`;
    }
};