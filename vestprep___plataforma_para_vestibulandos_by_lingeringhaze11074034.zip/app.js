import { createApp } from 'vue';
import config from './config.js';
import { simuladoManager } from './simulado.js';
import { resumoViewer } from './resumo.js';
import { countdownTimer } from './countdown.js';

const app = createApp({
    data() {
        return {
            activePage: 'home',
            activeSubject: null,
            activeSimulado: null,
            activeTopic: null,
            filters: {
                vestibular: 'todos',
                year: 'todos',
                simVestibular: 'todos',
                subject: 'todos'
            },
            editais: config.editais,
            simulados: config.simulados,
            subjects: config.subjects,
            testimonials: config.testimonials,
            
            // Calendário
            currentMonth: new Date().getMonth(),
            currentYear: new Date().getFullYear(),
            weekdays: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
            selectedDay: null,
            calendarEvents: config.calendarEvents,
            
            // Simulado em andamento
            currentSimulado: null,
            currentQuestion: 0,
            userAnswers: [],
            simuladoTime: 0,
            simuladoTimer: null,
            simuladoFinished: false,
            simuladoResult: null
        };
    },
    computed: {
        filteredEditais() {
            return this.editais.filter(edital => {
                if (this.filters.vestibular !== 'todos' && edital.type.toLowerCase() !== this.filters.vestibular) {
                    return false;
                }
                if (this.filters.year !== 'todos' && edital.year !== this.filters.year) {
                    return false;
                }
                return true;
            });
        },
        filteredSimulados() {
            return this.simulados.filter(simulado => {
                if (this.filters.simVestibular !== 'todos' && simulado.type.toLowerCase() !== this.filters.simVestibular) {
                    return false;
                }
                if (this.filters.subject !== 'todos' && !simulado.subjects.includes(this.filters.subject)) {
                    return false;
                }
                return true;
            });
        },
        currentMonthName() {
            const months = [
                'Janeiro', 'Fevereiro', 'Março', 'Abril', 
                'Maio', 'Junho', 'Julho', 'Agosto', 
                'Setembro', 'Outubro', 'Novembro', 'Dezembro'
            ];
            return months[this.currentMonth];
        },
        calendarDays() {
            const firstDay = new Date(this.currentYear, this.currentMonth, 1);
            const lastDay = new Date(this.currentYear, this.currentMonth + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startDayOfWeek = firstDay.getDay();
            
            const days = [];
            
            // Dias do mês anterior
            const prevMonthLastDay = new Date(this.currentYear, this.currentMonth, 0).getDate();
            for (let i = startDayOfWeek - 1; i >= 0; i--) {
                days.push({
                    dayNumber: prevMonthLastDay - i,
                    currentMonth: false,
                    date: new Date(this.currentYear, this.currentMonth - 1, prevMonthLastDay - i),
                    events: []
                });
            }
            
            // Dias do mês atual
            for (let i = 1; i <= daysInMonth; i++) {
                const date = new Date(this.currentYear, this.currentMonth, i);
                days.push({
                    dayNumber: i,
                    currentMonth: true,
                    date: date,
                    events: this.getEventsForDate(date)
                });
            }
            
            // Dias do próximo mês
            const remainingDays = 42 - days.length; // 6 semanas x 7 dias
            for (let i = 1; i <= remainingDays; i++) {
                days.push({
                    dayNumber: i,
                    currentMonth: false,
                    date: new Date(this.currentYear, this.currentMonth + 1, i),
                    events: []
                });
            }
            
            return days;
        },
        getCurrentSubject() {
            return this.subjects.find(subject => subject.id === this.activeSubject) || {};
        }
    },
    methods: {
        setActivePage(page) {
            this.activePage = page;
            window.scrollTo(0, 0);
            
            // Reset simulado state when navigating away
            if (page !== 'simulado-taking' && this.simuladoTimer) {
                clearInterval(this.simuladoTimer);
                this.simuladoTimer = null;
            }
        },
        setActiveSubject(subjectId) {
            this.activeSubject = subjectId;
        },
        startSimulado(simuladoId) {
            this.currentSimulado = simuladoManager.getSimulado(simuladoId);
            this.activeSimulado = simuladoId;
            this.currentQuestion = 0;
            this.userAnswers = Array(this.currentSimulado.questions.length).fill(null);
            this.simuladoTime = 0;
            this.simuladoFinished = false;
            this.simuladoResult = null;
            
            // Start timer
            this.simuladoTimer = setInterval(() => {
                this.simuladoTime++;
            }, 1000);
            
            this.setActivePage('simulado-taking');
        },
        
        answerQuestion(optionIndex) {
            this.userAnswers[this.currentQuestion] = optionIndex;
        },
        
        nextQuestion() {
            if (this.currentQuestion < this.currentSimulado.questions.length - 1) {
                this.currentQuestion++;
            }
        },
        
        prevQuestion() {
            if (this.currentQuestion > 0) {
                this.currentQuestion--;
            }
        },
        
        finishSimulado() {
            clearInterval(this.simuladoTimer);
            this.simuladoTimer = null;
            this.simuladoFinished = true;
            this.simuladoResult = simuladoManager.calculateResult(this.currentSimulado, this.userAnswers);
        },
        
        viewResumo(topicId) {
            this.activeTopic = resumoViewer.getTopic(topicId);
            this.setActivePage('resumo-view');
        },
        
        formatTime(seconds) {
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = seconds % 60;
            return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        },
        
        getUpcomingEvents() {
            return countdownTimer.getUpcomingEvents(this.calendarEvents);
        },
        prevMonth() {
            if (this.currentMonth === 0) {
                this.currentMonth = 11;
                this.currentYear--;
            } else {
                this.currentMonth--;
            }
        },
        nextMonth() {
            if (this.currentMonth === 11) {
                this.currentMonth = 0;
                this.currentYear++;
            } else {
                this.currentMonth++;
            }
        },
        getEventsForDate(date) {
            return this.calendarEvents.filter(event => {
                const eventDate = new Date(event.date);
                return eventDate.getDate() === date.getDate() &&
                       eventDate.getMonth() === date.getMonth() &&
                       eventDate.getFullYear() === date.getFullYear();
            });
        },
        showEvents(day) {
            this.selectedDay = day;
        },
        isSameDay(date1, date2) {
            return date1.getDate() === date2.getDate() &&
                   date1.getMonth() === date2.getMonth() &&
                   date1.getFullYear() === date2.getFullYear();
        },
        formatDate(dateStr) {
            const date = new Date(dateStr);
            return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
        }
    }
});

window.vueApp = app.mount('#app');