export default {
    // Editais disponíveis
    editais: [
        {
            id: 1,
            title: "Edital ENEM 2023",
            year: "2023",
            type: "ENEM",
            description: "Edital completo do Exame Nacional do Ensino Médio de 2023"
        },
        {
            id: 2,
            title: "Edital FUVEST 2023",
            year: "2023",
            type: "FUVEST",
            description: "Edital da Fundação Universitária para o Vestibular de 2023 (USP)"
        },
        {
            id: 3,
            title: "Edital UNICAMP 2023",
            year: "2023",
            type: "UNICAMP",
            description: "Edital do vestibular da Universidade Estadual de Campinas de 2023"
        },
        {
            id: 4,
            title: "Edital UNESP 2023",
            year: "2023",
            type: "UNESP",
            description: "Edital da Universidade Estadual Paulista de 2023"
        },
        {
            id: 5,
            title: "Edital ENEM 2022",
            year: "2022",
            type: "ENEM",
            description: "Edital completo do Exame Nacional do Ensino Médio de 2022"
        },
        {
            id: 6,
            title: "Edital FUVEST 2022",
            year: "2022",
            type: "FUVEST",
            description: "Edital da Fundação Universitária para o Vestibular de 2022 (USP)"
        },
        {
            id: 7,
            title: "Edital UNICAMP 2022",
            year: "2022",
            type: "UNICAMP",
            description: "Edital do vestibular da Universidade Estadual de Campinas de 2022"
        },
        {
            id: 8,
            title: "Edital ENEM 2021",
            year: "2021",
            type: "ENEM",
            description: "Edital completo do Exame Nacional do Ensino Médio de 2021"
        }
    ],
    
    // Simulados disponíveis
    simulados: [
        {
            id: 1,
            title: "Simulado Completo ENEM",
            type: "ENEM",
            questions: 180,
            duration: "5h30min",
            difficulty: "Médio",
            subjects: ["todos"]
        },
        {
            id: 2,
            title: "Simulado Matemática ENEM",
            type: "ENEM",
            questions: 45,
            duration: "1h30min",
            difficulty: "Médio",
            subjects: ["matematica"]
        },
        {
            id: 3,
            title: "Simulado Linguagens ENEM",
            type: "ENEM",
            questions: 45,
            duration: "1h30min",
            difficulty: "Médio",
            subjects: ["portugues", "ingles"]
        },
        {
            id: 4,
            title: "Simulado Ciências da Natureza ENEM",
            type: "ENEM",
            questions: 45,
            duration: "1h30min",
            difficulty: "Difícil",
            subjects: ["fisica", "quimica", "biologia"]
        },
        {
            id: 5,
            title: "Simulado Primeira Fase FUVEST",
            type: "FUVEST",
            questions: 90,
            duration: "5h",
            difficulty: "Difícil",
            subjects: ["todos"]
        },
        {
            id: 6,
            title: "Simulado Matemática FUVEST",
            type: "FUVEST",
            questions: 15,
            duration: "1h",
            difficulty: "Difícil",
            subjects: ["matematica"]
        },
        {
            id: 7,
            title: "Simulado UNICAMP Fase 1",
            type: "UNICAMP",
            questions: 72,
            duration: "5h",
            difficulty: "Médio",
            subjects: ["todos"]
        },
        {
            id: 8,
            title: "Simulado Português e Redação",
            type: "ENEM",
            questions: 30,
            duration: "2h",
            difficulty: "Fácil",
            subjects: ["portugues"]
        }
    ],
    
    // Matérias e tópicos
    subjects: [
        {
            id: 1,
            name: "Matemática",
            icon: "∑",
            color: "#4285F4",
            topics: 12,
            contentTopics: [
                {
                    id: 101,
                    title: "Funções",
                    description: "Funções do 1º e 2º graus, funções exponenciais e logarítmicas."
                },
                {
                    id: 102,
                    title: "Geometria Plana",
                    description: "Áreas e perímetros de figuras planas, semelhança de triângulos."
                },
                {
                    id: 103,
                    title: "Geometria Espacial",
                    description: "Volumes e áreas de superfícies de sólidos geométricos."
                },
                {
                    id: 104,
                    title: "Trigonometria",
                    description: "Relações trigonométricas no triângulo retângulo e no círculo."
                },
                {
                    id: 105,
                    title: "Análise Combinatória",
                    description: "Princípio fundamental da contagem, arranjos, combinações e permutações."
                }
            ]
        },
        {
            id: 2,
            name: "Física",
            icon: "⚛",
            color: "#EA4335",
            topics: 10,
            contentTopics: [
                {
                    id: 201,
                    title: "Mecânica",
                    description: "Cinemática, dinâmica e estática."
                },
                {
                    id: 202,
                    title: "Termofísica",
                    description: "Termodinâmica, calorimetria e gases ideais."
                },
                {
                    id: 203,
                    title: "Ondulatória",
                    description: "Ondas mecânicas, ondas sonoras e ondas eletromagnéticas."
                },
                {
                    id: 204,
                    title: "Óptica",
                    description: "Óptica geométrica, reflexão e refração da luz."
                },
                {
                    id: 205,
                    title: "Eletromagnetismo",
                    description: "Eletrostática, eletrodinâmica e magnetismo."
                }
            ]
        },
        {
            id: 3,
            name: "Química",
            icon: "⚗",
            color: "#FBBC05",
            topics: 9,
            contentTopics: [
                {
                    id: 301,
                    title: "Química Geral",
                    description: "Estrutura atômica, tabela periódica e ligações químicas."
                },
                {
                    id: 302,
                    title: "Físico-Química",
                    description: "Soluções, termoquímica, cinética química e equilíbrio químico."
                },
                {
                    id: 303,
                    title: "Química Orgânica",
                    description: "Funções orgânicas, isomeria e reações orgânicas."
                },
                {
                    id: 304,
                    title: "Química Ambiental",
                    description: "Poluição, tratamento de água e efeito estufa."
                }
            ]
        },
        {
            id: 4,
            name: "Biologia",
            icon: "🧬",
            color: "#34A853",
            topics: 10,
            contentTopics: [
                {
                    id: 401,
                    title: "Citologia",
                    description: "Estrutura celular, organelas e divisão celular."
                },
                {
                    id: 402,
                    title: "Genética",
                    description: "Leis de Mendel, genética molecular e biotecnologia."
                },
                {
                    id: 403,
                    title: "Evolução",
                    description: "Teorias evolutivas, especiação e evidências da evolução."
                },
                {
                    id: 404,
                    title: "Ecologia",
                    description: "Relações ecológicas, ciclos biogeoquímicos e biomas."
                },
                {
                    id: 405,
                    title: "Fisiologia Animal",
                    description: "Sistemas circulatório, respiratório, digestório e nervoso."
                }
            ]
        },
        {
            id: 5,
            name: "História",
            icon: "📜",
            color: "#7B1FA2",
            topics: 8,
            contentTopics: [
                {
                    id: 501,
                    title: "Brasil Colônia",
                    description: "Descobrimento, ciclos econômicos e sociedade colonial."
                },
                {
                    id: 502,
                    title: "Brasil Império",
                    description: "Independência, Primeiro e Segundo Reinados."
                },
                {
                    id: 503,
                    title: "Brasil República",
                    description: "Proclamação da República, Era Vargas e Ditadura Militar."
                },
                {
                    id: 504,
                    title: "História Antiga",
                    description: "Mesopotâmia, Egito, Grécia e Roma."
                },
                {
                    id: 505,
                    title: "História Moderna",
                    description: "Renascimento, Reformas Religiosas e Iluminismo."
                }
            ]
        },
        {
            id: 6,
            name: "Geografia",
            icon: "🌎",
            color: "#0097A7",
            topics: 8,
            contentTopics: [
                {
                    id: 601,
                    title: "Geografia Física",
                    description: "Clima, relevo, hidrografia e vegetação."
                },
                {
                    id: 602,
                    title: "Geografia Humana",
                    description: "Demografia, urbanização e migrações."
                },
                {
                    id: 603,
                    title: "Geografia Econômica",
                    description: "Globalização, blocos econômicos e industrialização."
                },
                {
                    id: 604,
                    title: "Geografia do Brasil",
                    description: "Regionalização, aspectos físicos e econômicos do Brasil."
                }
            ]
        },
        {
            id: 7,
            name: "Português",
            icon: "📝",
            color: "#FF5722",
            topics: 7,
            contentTopics: [
                {
                    id: 701,
                    title: "Gramática",
                    description: "Morfologia, sintaxe e fonologia."
                },
                {
                    id: 702,
                    title: "Interpretação de Texto",
                    description: "Análise de textos literários e não-literários."
                },
                {
                    id: 703,
                    title: "Literatura",
                    description: "Escolas literárias brasileiras e portuguesas."
                },
                {
                    id: 704,
                    title: "Redação",
                    description: "Dissertação argumentativa, narração e descrição."
                }
            ]
        },
        {
            id: 8,
            name: "Inglês",
            icon: "🌐",
            color: "#3949AB",
            topics: 5,
            contentTopics: [
                {
                    id: 801,
                    title: "Gramática Inglesa",
                    description: "Tempos verbais, preposições e artigos."
                },
                {
                    id: 802,
                    title: "Interpretação de Texto",
                    description: "Estratégias de leitura e compreensão textual."
                },
                {
                    id: 803,
                    title: "Vocabulário",
                    description: "Expressões idiomáticas e falsos cognatos."
                }
            ]
        }
    ],
    
    // Depoimentos
    testimonials: [
        {
            id: 1,
            quote: "Graças aos simulados da VestPrep, consegui me preparar muito bem para o ENEM e fui aprovado em Medicina na USP!",
            author: "Carlos Silva",
            university: "Medicina USP"
        },
        {
            id: 2,
            quote: "Os resumos são excelentes! Consegui organizar meus estudos e fui aprovada em Direito na UNICAMP logo na primeira tentativa.",
            author: "Ana Oliveira",
            university: "Direito UNICAMP"
        },
        {
            id: 3,
            quote: "A plataforma me ajudou muito com os simulados específicos para a FUVEST, que são bem diferentes dos outros vestibulares.",
            author: "Pedro Santos",
            university: "Engenharia USP"
        },
        {
            id: 4,
            quote: "Os resumos de Matemática e Física foram fundamentais para eu entender conceitos complexos. Aprovada em Engenharia na UNESP!",
            author: "Juliana Pereira",
            university: "Engenharia UNESP"
        }
    ],
    
    // Eventos do calendário
    calendarEvents: [
        {
            id: 1,
            title: "Abertura das inscrições ENEM 2023",
            description: "Início do período de inscrições para o ENEM 2023",
            date: "2023-05-15",
            time: "10:00",
            type: "inscricao"
        },
        {
            id: 2,
            title: "Fim das inscrições ENEM 2023",
            description: "Encerramento do período de inscrições para o ENEM 2023",
            date: "2023-06-10",
            time: "23:59",
            type: "inscricao"
        },
        {
            id: 3,
            title: "Provas ENEM - 1º Dia",
            description: "Linguagens, Códigos e suas Tecnologias, Redação e Ciências Humanas",
            date: "2023-11-05",
            time: "13:00",
            type: "prova"
        },
        {
            id: 4,
            title: "Provas ENEM - 2º Dia",
            description: "Ciências da Natureza e Matemática",
            date: "2023-11-12",
            time: "13:00",
            type: "prova"
        },
        {
            id: 5,
            title: "Inscrições FUVEST 2024",
            description: "Início das inscrições para o vestibular da FUVEST 2024",
            date: "2023-08-21",
            time: "12:00",
            type: "inscricao"
        },
        {
            id: 6,
            title: "Fim das inscrições FUVEST 2024",
            description: "Encerramento das inscrições para o vestibular da FUVEST 2024",
            date: "2023-10-08",
            time: "23:59",
            type: "inscricao"
        },
        {
            id: 7,
            title: "Prova FUVEST - 1ª Fase",
            description: "Prova de Conhecimentos Gerais",
            date: "2023-11-19",
            time: "13:00",
            type: "prova"
        },
        {
            id: 8,
            title: "Divulgação Resultados ENEM",
            description: "Divulgação das notas do ENEM 2023",
            date: "2024-01-15",
            time: "11:00",
            type: "resultado"
        }
    ]
};

